import pandas as pd
import seaborn as sbs
from textblob import TextBlob
import re
df = pd.read_csv('social_media_posts.csv')

# Let's start by handling missing values.
print("----- Missing values count -----")
print(df.isnull().sum())

median_likes= df['likes'].median()
df['likes'] = df['likes'].fillna(median_likes)
print(f"\nFilled 'likes' with median value: {median_likes}")

mean_shares=df['shares'].mean()
df['shares'] = df['shares'].fillna(mean_shares)
print(f"Filled 'shares' with mean value: {round(mean_shares)}")

df['post_content']= df['post_content'].fillna('No Text')
print("Filled 'post_content' with 'No Text'")

# Let's clean post_content

#helpers
URL_RE = re.compile(r'https?://\S+|www\.\S+')
TAG_RE = re.compile(r'[#@][A-Za-z0-9_]+')
EMO_RE = re.compile(r'[\U00010000-\U0010ffff]')
PUNC_RE = re.compile(r'[^\w\s]')



# functions
def clean_post_content(text):
 """: Cleans the text by removing URLs, mentions, hashtags,punctuation, emojis, and extra spaces. Returns a plain string containing only the cleaned text."""
 text = str(text)
 text = re.sub(r'https?://\S+|www\.\S+', '', text) # remove URLs
 text = re.sub(r'[@#][A-Za-z0-9_]+', '', text)  # remove # and @
 text = re.sub(r'[\U00010000-\U0010ffff]', '', text) # remove emojis
 text = re.sub(r'[^\w\s]', '', text)  # remove punctuation

 return text


df['clean_post_content'] = df['post_content'].apply(clean_post_content)

# Lastly, we will Convert post_date to datetime format and extract hashtags and store them in a new column Hashtags

df['post_date'] = pd.to_datetime(df['post_date'], errors='coerce')


def extract_hashtags(text: str) -> list[str]:
    return re.findall(r'#\w+', str(text))

def extract_mentions(text: str) -> list[str]:
    return re.findall(r'@\w+', str(text))

df['Hashtags'] = df['post_content'].apply(extract_hashtags)

#Identify the Top 3 users by total engagement (average likes + average shares).

def get_avg_engagement(df):
    return df.groupby('user_id', sort=True)[['likes', 'shares']].mean().reset_index()

def get_top3_engagement(df):
    g = get_avg_engagement(df).copy()           # uses your test-friendly function
    g['total_engagement'] = g['likes'] + g['shares']
    return g.sort_values('total_engagement', ascending=False).head(3)

top3_users = get_top3_engagement(df)
print("\nTop 3 users by total engagement (avg likes + avg shares):")
print(top3_users)


#Determine the Top 5 hashtags based on frequency of appearance.
hashtags_serie= df['Hashtags'].explode()
hashtags_serie= hashtags_serie.dropna()
top5_hashttags= hashtags_serie.value_counts().head(5)

print("Top 5 hashtags by frequency of appearance: ")
print(f"\n")
print(top5_hashttags)

# Sentiment Analysis

def get_sentiment(text: str) -> float:
    return float(TextBlob(str(text)).sentiment.polarity)

df['polarity']= df['post_content'].apply(get_sentiment)

def label_sentiment(p):
  if p>0: return 'positive'
  elif p<0: return 'negative'
  else: return 'neutral'

df['sentiment']= df['polarity'].apply(label_sentiment)

print(' overall sentiment distribution:', df['sentiment'].value_counts())

avg_sentiment= df.groupby('user_id')['polarity'].mean()
print(f'\n')
print(avg_sentiment)

#Visualisations

#Wordcloud
from wordcloud import WordCloud
from collections import Counter
import matplotlib.pyplot as plt

freqs = hashtags_serie.value_counts().to_dict()
wc = WordCloud(width=1200, height=600, background_color='white')
wc = wc.generate_from_frequencies(freqs)
plt.figure(figsize=(10, 5))
plt.imshow(wc)
plt.axis('off')
plt.savefig('wordcloud.png')

# Monthly Posts (line plot)
monthly_posts = df['post_date'].dt.to_period('M').value_counts().sort_index()

plt.plot(monthly_posts.index.astype(str), monthly_posts.values, marker='o')
plt.title('Monthly Posts')
plt.xlabel('Month')
plt.ylabel('Number of Posts')
plt.xticks(rotation=45, ha='right')
plt.savefig('monthly_posts.png')

#Likes vs Shares (scatter plot)
plt.figure(figsize=(8,6))
plt.scatter(df['likes'], df['shares'], color='royalblue', alpha=0.7)
plt.title('Likes vs Shares', fontsize=14)
plt.xlabel('Likes', fontsize=12)
plt.ylabel('Shares', fontsize=12)
plt.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()
plt.savefig('likes_vs_shares.png')

plt.figure(figsize=(12,5))
#plt.bar(avg_sentiment.index.astype(str), avg_sentiment.values, color='skyblue')
avg_sentiment.head(20).plot(kind='bar', figsize=(10,5)) # to make it readable
#plt.title('Average Sentiment per User')
plt.title('Top 20 Users by Average Sentiment')
plt.xlabel('User ID')
plt.ylabel('Average Sentiment Score')
plt.xticks(rotation=90, fontsize=7)
plt.tight_layout()
plt.savefig('avg_sentiment_per_user.png', dpi=200)

print("\n✅ All visualizations saved successfully!")
