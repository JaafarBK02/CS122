HW4: Social Media Analysis

Student Name: Jaafar Ben Khaled
SJSU ID: [Your 9-digit SJSU ID]
Course: CS 122 – Data Science Fundamentals
Date: October 2025

📊 Project Overview

This project analyzes a dataset of social media posts to uncover insights about engagement levels, popular hashtags, and sentiment trends.
The analysis includes data cleaning, hashtag extraction, engagement metrics, sentiment analysis using TextBlob, and visualization of key insights.

🧩 Steps Performed
1️⃣ Data Wrangling

Handled missing values:

Filled likes with the median

Filled shares with the mean

Replaced missing post_content with "No Text"

Cleaned post text using regex to remove:

URLs, mentions, hashtags, punctuation, and emojis

Created new columns:

clean_post_content – cleaned text

Hashtags – extracted list of hashtags

post_date – converted to datetime format

2️⃣ Data Analysis

Computed each user’s average likes and shares using get_avg_engagement(df).

Identified Top 3 Users by total engagement (average likes + average shares).

Determined Top 5 Hashtags based on frequency of appearance.

3️⃣ Sentiment Analysis

Used TextBlob to compute sentiment polarity for each post.

Classified posts into:

Positive

Neutral

Negative

Calculated overall sentiment distribution.

Computed average sentiment score per user.

4️⃣ Visualizations

All plots were saved in .png format:

wordcloud.png	--> Word cloud of the most frequent hashtags
monthly_posts.png --> 	Line plot of number of posts per month
likes_vs_shares.png --> 	Scatter plot showing correlation between likes and shares
avg_sentiment_per_user.png --> 	Bar chart showing top users by average sentiment

